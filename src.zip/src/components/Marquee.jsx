// Marquee.jsx
// Drop this into your components folder and import it anywhere in App.jsx

import { useRef, useEffect } from 'react';
import gsap from 'gsap';

/* ── Items to scroll ── */
const MARQUEE_ITEMS = [
  { icon: '⬡', label: 'AI Automation' },
  { icon: '◈', label: 'Cloud Solutions' },
  { icon: '⬡', label: 'Cybersecurity' },
  { icon: '◈', label: 'IoT Systems' },
  { icon: '⬡', label: 'Data Analytics' },
  { icon: '◈', label: 'Machine Learning' },
  { icon: '⬡', label: 'Edge Computing' },
  { icon: '◈', label: 'Digital Twins' },
];

/* Duplicate for seamless loop */
const ITEMS = [...MARQUEE_ITEMS, ...MARQUEE_ITEMS];

export default function Marquee() {
  const track1Ref = useRef(null);
  const track2Ref = useRef(null);
  const tween1Ref = useRef(null);
  const tween2Ref = useRef(null);

  useEffect(() => {
    const speed = 38; // seconds for one full loop

    /* Row 1 — scrolls left */
    tween1Ref.current = gsap.to(track1Ref.current, {
      xPercent: -50,
      duration: speed,
      ease: 'none',
      repeat: -1,
    });

    /* Row 2 — scrolls right */
    tween2Ref.current = gsap.fromTo(
      track2Ref.current,
      { xPercent: -50 },
      { xPercent: 0, duration: speed, ease: 'none', repeat: -1 }
    );

    /* Pause on hover */
    const el = track1Ref.current?.closest('.marquee');
    const pause = () => {
      tween1Ref.current?.pause();
      tween2Ref.current?.pause();
    };
    const resume = () => {
      tween1Ref.current?.resume();
      tween2Ref.current?.resume();
    };
    el?.addEventListener('mouseenter', pause);
    el?.addEventListener('mouseleave', resume);

    return () => {
      tween1Ref.current?.kill();
      tween2Ref.current?.kill();
      el?.removeEventListener('mouseenter', pause);
      el?.removeEventListener('mouseleave', resume);
    };
  }, []);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@600;800&family=Exo+2:wght@300;500;600&display=swap');

        .marquee {
          --clr-bg:      #050916;
          --clr-navy:    #080f2e;
          --clr-blue:    #1565c0;
          --clr-accent:  #00e5ff;
          --clr-sky:     #4fc3f7;
          --clr-text:    #cde4ff;
          --clr-muted:   rgba(180,210,255,0.55);

          position: relative;
          width: 100%;
          background: var(--clr-navy);
          border-top:    1px solid rgba(79,195,247,0.12);
          border-bottom: 1px solid rgba(79,195,247,0.12);
          padding: 0;
          overflow: hidden;
          font-family: 'Exo 2', sans-serif;
        }

        /* top scan-line accent */
        .marquee::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg,
            transparent 0%,
            rgba(0,229,255,0.6) 40%,
            rgba(79,195,247,0.6) 60%,
            transparent 100%
          );
        }

        /* edge fade masks */
        .marquee__mask {
          position: absolute;
          inset: 0;
          pointer-events: none;
          z-index: 2;
          background:
            linear-gradient(90deg,
              var(--clr-navy) 0%,
              transparent 12%,
              transparent 88%,
              var(--clr-navy) 100%
            );
        }

        .marquee__rows {
          display: flex;
          flex-direction: column;
          gap: 0;
        }

        /* ── single row ── */
        .marquee__row {
          display: flex;
          overflow: hidden;
          padding: 14px 0;
          position: relative;
        }

        .marquee__row--dim {
          opacity: 0.55;
          padding: 10px 0;
          background: rgba(5,9,22,0.4);
          border-top: 1px solid rgba(79,195,247,0.07);
        }

        .marquee__track {
          display: flex;
          flex-shrink: 0;
          align-items: center;
          gap: 0;
          will-change: transform;
          white-space: nowrap;
        }

        /* ── individual pill ── */
        .marquee__item {
          display: inline-flex;
          align-items: center;
          gap: 0.65rem;
          padding: 0.55rem 1.6rem;
          margin: 0 0.55rem;
          border-radius: 100px;
          border: 1px solid rgba(79,195,247,0.18);
          background: rgba(21,101,192,0.08);
          color: var(--clr-text);
          font-size: 0.82rem;
          font-weight: 500;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          cursor: default;
          transition: border-color 0.3s, background 0.3s, box-shadow 0.3s;
          position: relative;
          overflow: hidden;
        }

        .marquee__item::before {
          content: '';
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg,
            rgba(0,229,255,0.05) 0%,
            transparent 60%
          );
          opacity: 0;
          transition: opacity 0.3s;
        }

        .marquee__item:hover {
          border-color: rgba(0,229,255,0.55);
          background: rgba(0,229,255,0.08);
          box-shadow:
            0 0 18px rgba(0,229,255,0.15),
            inset 0 0 12px rgba(0,229,255,0.05);
          color: var(--clr-accent);
        }

        .marquee__item:hover::before { opacity: 1; }

        .marquee__icon {
          font-size: 0.95rem;
          color: var(--clr-accent);
          filter: drop-shadow(0 0 5px rgba(0,229,255,0.6));
          line-height: 1;
          animation: iconPulse 3s ease-in-out infinite;
        }

        .marquee__item:nth-child(even) .marquee__icon {
          color: var(--clr-sky);
          filter: drop-shadow(0 0 5px rgba(79,195,247,0.6));
          animation-delay: 1.5s;
        }

        @keyframes iconPulse {
          0%, 100% { opacity: 1;   filter: drop-shadow(0 0 5px rgba(0,229,255,0.6)); }
          50%       { opacity: 0.6; filter: drop-shadow(0 0 2px rgba(0,229,255,0.3)); }
        }

        /* ── divider dot between rows ── */
        .marquee__divider {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 5px 0;
          background: var(--clr-navy);
        }

        .marquee__dot {
          width: 3px; height: 3px;
          border-radius: 50%;
          background: rgba(79,195,247,0.35);
        }
        .marquee__dot--bright {
          background: var(--clr-accent);
          box-shadow: 0 0 6px var(--clr-accent);
        }

        /* ── section label ── */
        .marquee__label {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          left: 0;
          z-index: 3;
          padding: 0.3rem 1.2rem;
          font-family: 'Orbitron', monospace;
          font-size: 0.58rem;
          font-weight: 600;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--clr-muted);
          pointer-events: none;
          user-select: none;
          opacity: 0;  /* hidden — purely decorative fallback */
        }
      `}</style>

      <div className="marquee" aria-label="Technologies and services">
        <div className="marquee__mask" aria-hidden="true" />

        <div className="marquee__rows">

          {/* ── Row 1: scrolls LEFT ── */}
          <div className="marquee__row">
            <div ref={track1Ref} className="marquee__track">
              {ITEMS.map((item, i) => (
                <span key={i} className="marquee__item">
                  <span className="marquee__icon" aria-hidden="true">{item.icon}</span>
                  {item.label}
                </span>
              ))}
            </div>
          </div>

          {/* ── Dot divider ── */}
          <div className="marquee__divider" aria-hidden="true">
            {[...Array(5)].map((_, i) => (
              <span key={i} className={`marquee__dot${i === 2 ? ' marquee__dot--bright' : ''}`} />
            ))}
          </div>

          {/* ── Row 2: scrolls RIGHT (dimmed) ── */}
          <div className="marquee__row marquee__row--dim">
            <div ref={track2Ref} className="marquee__track">
              {ITEMS.map((item, i) => (
                <span key={i} className="marquee__item">
                  <span className="marquee__icon" aria-hidden="true">{item.icon}</span>
                  {item.label}
                </span>
              ))}
            </div>
          </div>

        </div>
      </div>
    </>
  );
}