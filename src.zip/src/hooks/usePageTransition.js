import { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import gsap from 'gsap';

export const usePageTransition = () => {
  const navigate = useNavigate();
  const panel1Ref = useRef(null);
  const panel2Ref = useRef(null);

  const transitionTo = (path) => {
    // Create exit overlay on the fly
    const panel1 = document.createElement('div');
    const panel2 = document.createElement('div');

    const baseStyle = {
      position: 'fixed', inset: '0',
      zIndex: '9999', transform: 'translateY(100%)',
    };

    Object.assign(panel1.style, { ...baseStyle, backgroundColor: '#1a1a2e' });
    Object.assign(panel2.style, { ...baseStyle, backgroundColor: '#0a0a0a' });

    document.body.appendChild(panel1);
    document.body.appendChild(panel2);

    const tl = gsap.timeline({
      onComplete: () => {
        navigate(path);
        // Cleanup after navigation
        setTimeout(() => {
          panel1.remove();
          panel2.remove();
        }, 100);
      }
    });

    tl
      .to(panel1, { yPercent: 0, duration: 0.45, ease: 'power3.inOut' })
      .to(panel2, { yPercent: 0, duration: 0.4, ease: 'power3.inOut' }, '<+=0.07');
  };

  return { transitionTo };
};